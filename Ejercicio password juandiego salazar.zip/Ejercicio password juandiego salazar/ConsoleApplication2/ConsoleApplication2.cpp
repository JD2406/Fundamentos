#include <iostream>
#include <string>
#include "Usuario.h"

using namespace std;

int main()
{
    string usuario, contrasenia;
    Usuario usuario1("yo" , "1234");
    cout << "Ingresar usuario: ";
    cin >> usuario;
    cout << "Ingresar contrasenia: ";
    cin >> contrasenia;
    if (usuario1.Verificarlogin(usuario, contrasenia))
        cout << "Puedes pasar" << endl;
    else
        cout << "Error no puedes pasar";
}

